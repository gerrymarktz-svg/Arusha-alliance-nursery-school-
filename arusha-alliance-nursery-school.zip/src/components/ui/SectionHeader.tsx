import { motion } from "motion/react";

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  light?: boolean;
  align?: 'left' | 'center';
}

export const SectionHeader = ({ title, subtitle, light = false, align = 'center' }: SectionHeaderProps) => {
  return (
    <div className={`mb-16 ${align === 'center' ? 'text-center' : 'text-left'}`}>
      <motion.span
        initial={{ opacity: 0, x: -20 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        className={`inline-block px-4 py-1 rounded-full text-xs font-bold tracking-widest uppercase mb-4 ${
          light ? 'bg-white/20 text-white' : 'bg-primary/10 text-primary'
        }`}
      >
        {title}
      </motion.span>
      {subtitle && (
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className={`text-3xl md:text-5xl font-display font-extrabold leading-tight ${
            light ? 'text-white' : 'text-gray-900'
          }`}
        >
          {subtitle}
        </motion.h2>
      )}
    </div>
  );
};
