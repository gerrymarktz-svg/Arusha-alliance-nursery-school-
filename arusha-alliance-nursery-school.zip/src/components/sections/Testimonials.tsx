import { motion } from "motion/react";
import { Star, MessageCircle, Quote } from "lucide-react";
import { SectionHeader } from "../ui/SectionHeader";

export const Testimonials = () => {
  const testimonials = [
    {
      name: "Elizabeth S.",
      role: "Parent",
      image: "https://i.pravatar.cc/150?u=liz",
      content: "Arusha Alliance changed my daughter's life. Her confidence has soared, and she actually begs to go to school every morning!",
      rating: 5
    },
    {
      name: "Marcus M.",
      role: "Parent",
      image: "https://i.pravatar.cc/150?u=mark",
      content: "The teachers are incredibly caring. I feel completely safe leaving my son here, knowing he's getting both education and warmth.",
      rating: 5
    },
    {
      name: "Fatima J.",
      role: "Parent",
      image: "https://i.pravatar.cc/150?u=fati",
      content: "Truly international standard facilities right here in Arusha. The STEM programs for small kids are very impressive.",
      rating: 5
    }
  ];

  return (
    <section className="section-padding bg-white relative overflow-hidden">
      {/* Background blobs */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-[300px] h-[300px] bg-secondary/10 rounded-full blur-[100px] -z-10" />
      <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-primary/10 rounded-full blur-[100px] -z-10" />

      <div className="max-w-7xl mx-auto">
        <SectionHeader 
          title="Testimonials" 
          subtitle="What Our Parents Say" 
        />

        <div className="grid lg:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="relative p-10 bg-white rounded-[40px] shadow-premium border border-gray-100 hover:-translate-y-2 transition-transform duration-500"
            >
              <div className="absolute -top-6 left-10 w-12 h-12 bg-accent rounded-2xl flex items-center justify-center text-white shadow-lg shadow-accent/20">
                <Quote size={24} />
              </div>

              <div className="flex gap-1 mb-6 mt-2">
                {[...Array(t.rating)].map((_, idx) => (
                  <Star key={idx} size={16} className="text-secondary fill-secondary" />
                ))}
              </div>

              <p className="text-gray-600 mb-8 italic leading-relaxed">"{t.content}"</p>

              <div className="flex items-center gap-4">
                <img src={t.image} alt={t.name} className="w-14 h-14 rounded-2xl object-cover border-2 border-primary/20" />
                <div>
                  <h4 className="font-display font-black text-lg text-gray-900">{t.name}</h4>
                  <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">{t.role}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
