import { motion } from "motion/react";
import { Shield, Users, Laptop, PlayCircle, Sun, Utensils, Truck, Lightbulb } from "lucide-react";
import { SectionHeader } from "../ui/SectionHeader";

export const Features = () => {
  const features = [
    { icon: Shield, title: "Safe Environment", desc: "24/7 Security and CCTV surveillance." },
    { icon: Users, title: "Qualified Teachers", desc: "Certified international standard educators." },
    { icon: Laptop, title: "Modern Learning", desc: "Interactive smartboards and digital literacy." },
    { icon: PlayCircle, title: "Outdoor Play", desc: "Expansive and safe adventure playgrounds." },
    { icon: Sun, title: "Active Lifestyle", desc: "Sports and physical education programs." },
    { icon: Utensils, title: "Healthy Meals", desc: "Nutritious balanced chef-prepared meals." },
    { icon: Truck, title: "Transport Services", desc: "Modern school buses with tracking systems." },
    { icon: Lightbulb, title: "STEM Education", desc: "Early introduction to science and math." },
  ];

  return (
    <section className="section-padding bg-primary relative overflow-hidden">
      {/* Decorative patterns */}
      <div className="absolute inset-0 opacity-[0.05] pointer-events-none">
        <div className="absolute top-0 right-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <SectionHeader 
          title="Why Arusha Alliance?" 
          subtitle="Exceptional Standards of Care" 
          light 
        />

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-white/10 backdrop-blur-md border border-white/20 p-8 rounded-[32px] hover:bg-white/15 transition-all duration-300 group"
            >
              <div className="w-14 h-14 bg-white/20 text-white rounded-2xl flex items-center justify-center mb-6 group-hover:rotate-12 transition-transform">
                <f.icon size={28} />
              </div>
              <h3 className="font-display font-extrabold text-xl text-white mb-3 tracking-tight">{f.title}</h3>
              <p className="text-white/70 text-sm leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
