import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, Phone, Mail, GraduationCap } from "lucide-react";

export const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", href: "#" },
    { name: "About", href: "#about" },
    { name: "Academics", href: "#academics" },
    { name: "Gallery", href: "#gallery" },
    { name: "Admissions", href: "#admissions" },
    { name: "Contact", href: "#contact" },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
        isScrolled ? "bg-white/90 backdrop-blur-lg shadow-lg py-4" : "bg-transparent py-6"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2 group">
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white shadow-lg group-hover:rotate-12 transition-transform">
            <GraduationCap size={24} />
          </div>
          <div>
            <span className={`block text-xl font-display font-black tracking-tight ${isScrolled ? 'text-gray-900' : 'text-white'}`}>
              ARUSHA ALLIANCE
            </span>
            <span className={`block text-[10px] font-bold tracking-[0.2em] uppercase ${isScrolled ? 'text-primary' : 'text-secondary'}`}>
              Nursery School
            </span>
          </div>
        </a>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className={`text-sm font-bold transition-all hover:text-primary ${
                isScrolled ? "text-gray-700" : "text-white"
              }`}
            >
              {link.name}
            </a>
          ))}
          <a
            href="#admissions"
            className="bg-accent text-white px-6 py-2 rounded-full text-sm font-bold hover:bg-accent/90 transition-all shadow-lg shadow-accent/20"
          >
            Enroll Now
          </a>
        </div>

        {/* Mobile Toggle */}
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className={`lg:hidden p-2 rounded-xl border ${
            isScrolled ? "text-gray-900 border-gray-200" : "text-white border-white/20"
          }`}
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-white border-b overflow-hidden"
          >
            <div className="px-6 py-8 flex flex-col gap-6">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-lg font-bold text-gray-900 hover:text-primary"
                >
                  {link.name}
                </a>
              ))}
              <hr className="border-gray-100" />
              <div className="flex flex-col gap-4">
                <div className="flex items-center gap-3 text-gray-600">
                  <Phone size={18} className="text-primary" />
                  <span className="text-sm font-semibold">+255 755 667 637</span>
                </div>
                <div className="flex items-center gap-3 text-gray-600">
                  <Mail size={18} className="text-primary" />
                  <span className="text-sm font-semibold">info@arushaalliance.sc.tz</span>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};
