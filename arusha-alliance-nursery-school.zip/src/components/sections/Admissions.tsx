import { useState, FormEvent } from "react";
import { motion } from "motion/react";
import { Send, CheckCircle2, FileDown } from "lucide-react";
import { SectionHeader } from "../ui/SectionHeader";
import { Card } from "../ui/Card";
import { Button } from "../ui/Button";

export const Admissions = () => {
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 5000);
  };

  return (
    <section id="admissions" className="section-padding bg-gray-50/50">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-20 items-start">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <SectionHeader 
              title="Admissions" 
              subtitle="Join Our Educational Family" 
              align="left"
            />
            
            <p className="text-lg text-gray-600 mb-10 leading-relaxed">
              Enrolling your child at Arusha Alliance Nursery School is the first step towards a bright future. We follow a simple, transparent admission process designed to ensure a smooth transition for your little ones.
            </p>

            <div className="space-y-8 mb-12">
              {[
                { step: "01", title: "Visit The School", desc: "Book a tour to see our facilities and meet our friendly staff." },
                { step: "02", title: "Fill Application", desc: "Complete the online enrollment form or download the PDF below." },
                { step: "03", title: "Assessment", desc: "A soft assessment to understand your child's social and cognitive needs." },
                { step: "04", title: "Final Enrollment", desc: "Secure your place with registration after confirmation." },
              ].map((item, i) => (
                <div key={i} className="flex gap-6 group">
                  <div className="flex-shrink-0 w-12 h-12 rounded-2xl bg-white shadow-premium flex items-center justify-center font-display font-black text-primary text-xl group-hover:bg-primary group-hover:text-white transition-all duration-300">
                    {item.step}
                  </div>
                  <div>
                    <h4 className="font-display font-bold text-xl mb-1 text-gray-900">{item.title}</h4>
                    <p className="text-gray-500 text-sm">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-8 bg-primary rounded-[32px] text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl shadow-primary/20">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                  <FileDown size={24} />
                </div>
                <div>
                  <h5 className="font-display font-bold text-lg">Admission Package</h5>
                  <p className="text-white/70 text-xs uppercase font-bold tracking-widest">PDF • 2.4 MB</p>
                </div>
              </div>
              <Button variant="secondary" size="md">Download PDF</Button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <Card className="!p-10 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1 h-full bg-primary" />
              <h3 className="font-display font-black text-3xl mb-8 text-gray-900 italic">Enrollment Form</h3>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Parent Name</label>
                    <input required type="text" className="w-full px-5 py-3 rounded-2xl bg-gray-50 border border-gray-100 focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all font-sans" placeholder="Full Name" />
                  </div>
                  <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Child Name</label>
                    <input required type="text" className="w-full px-5 py-3 rounded-2xl bg-gray-50 border border-gray-100 focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all font-sans" placeholder="Child's Full Name" />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Child Age</label>
                    <select className="w-full px-5 py-3 rounded-2xl bg-gray-50 border border-gray-100 focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all font-sans">
                      <option>Under 3 Years</option>
                      <option>3 - 4 Years</option>
                      <option>4 - 5 Years</option>
                      <option>5 - 6 Years</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Phone Number</label>
                    <input required type="tel" className="w-full px-5 py-3 rounded-2xl bg-gray-50 border border-gray-100 focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all font-sans" placeholder="+255 755 667 637" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Email Address</label>
                  <input required type="email" className="w-full px-5 py-3 rounded-2xl bg-gray-50 border border-gray-100 focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all font-sans" placeholder="yourname@gmail.com" />
                </div>

                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Message (Optional)</label>
                  <textarea rows={4} className="w-full px-5 py-3 rounded-2xl bg-gray-50 border border-gray-100 focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all font-sans" placeholder="Questions or special needs..."></textarea>
                </div>

                <Button type="submit" variant="primary" size="lg" className="w-full gap-2">
                  {isSubmitted ? (
                    <>Application Sent! <CheckCircle2 size={20} /></>
                  ) : (
                    <>Send Application <Send size={20} /></>
                  )}
                </Button>
              </form>

              {isSubmitted && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-6 p-4 bg-success/10 border border-success/20 rounded-2xl text-success flex items-start gap-3"
                >
                  <CheckCircle2 size={24} className="flex-shrink-0" />
                  <p className="text-sm font-semibold italic">Thank you! We've received your application. Our admissions officer will contact you within 24 hours.</p>
                </motion.div>
              )}
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
