import { motion } from "motion/react";
import { Instagram, Facebook, Youtube, Twitter, MapPin, Phone, Mail, Clock, GraduationCap } from "lucide-react";

export const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-900 pt-20 pb-10 text-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid lg:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white">
                <GraduationCap size={24} />
              </div>
              <div className="font-display font-black tracking-tighter">
                <span className="block text-xl leading-none">ARUSHA ALLIANCE</span>
                <span className="block text-[10px] text-primary uppercase tracking-widest leading-none mt-1">Nursery School</span>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed mb-8">
              Empowering young minds through excellence, creativity, and discipline. Arusha Alliance is the home of joyful learning in Arusha, Tanzania.
            </p>
            <div className="flex gap-4">
              {[Facebook, Instagram, Youtube, Twitter].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:bg-primary hover:border-primary transition-all duration-300">
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display font-bold text-lg mb-8 uppercase tracking-widest text-primary">Quick Links</h4>
            <ul className="space-y-4">
              {["About Us", "Academics", "Gallery", "Admissions", "Contact", "Events"].map((link) => (
                <li key={link}>
                  <a href={`#${link.toLowerCase()}`} className="text-gray-400 hover:text-white transition-colors flex items-center gap-2 group">
                    <div className="w-1 hover:w-3 h-px bg-primary transition-all" />
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-display font-bold text-lg mb-8 uppercase tracking-widest text-primary">Contact Us</h4>
            <ul className="space-y-6">
              <li className="flex gap-4">
                <MapPin className="text-primary flex-shrink-0" size={20} />
                <span className="text-gray-400 text-sm">Morombo Area, Arusha, Tanzania</span>
              </li>
              <li className="flex gap-4">
                <Phone className="text-primary flex-shrink-0" size={20} />
                <span className="text-gray-400 text-sm font-semibold">+255 755 667 637</span>
              </li>
              <li className="flex gap-4">
                <Mail className="text-primary flex-shrink-0" size={20} />
                <span className="text-gray-400 text-sm">info@arushaalliance.sc.tz</span>
              </li>
            </ul>
          </div>

          {/* School Motto */}
          <div>
            <h4 className="font-display font-bold text-lg mb-8 uppercase tracking-widest text-primary">School Hours</h4>
            <ul className="space-y-6">
              <li className="flex gap-4">
                <Clock className="text-primary flex-shrink-0" size={20} />
                <div>
                  <span className="block text-sm text-white font-bold">Mon - Friday</span>
                  <span className="block text-xs text-gray-400 uppercase tracking-widest">08:00 AM - 04:00 PM</span>
                </div>
              </li>
              <li className="mt-8">
                <div className="bg-white/5 p-6 rounded-2xl border border-white/10 italic text-sm text-gray-300">
                  "Excellence, Creativity & Discipline for a Brighter Future."
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-10 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-gray-500 text-sm tracking-tight">&copy; {currentYear} Arusha Alliance Nursery School. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="text-gray-500 hover:text-white text-xs uppercase font-bold tracking-widest">Privacy Policy</a>
            <a href="#" className="text-gray-500 hover:text-white text-xs uppercase font-bold tracking-widest">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
