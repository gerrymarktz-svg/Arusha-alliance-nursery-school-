import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Search } from "lucide-react";
import { SectionHeader } from "../ui/SectionHeader";

export const Gallery = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [filter, setFilter] = useState("All");

  const categories = ["All", "Classes", "Playtime", "Events", "Sports"];
  
  const images = [
    { src: "https://images.unsplash.com/photo-1524069290683-0457abfe42c3?q=80&w=2670&auto=format&fit=crop", cat: "Classes", title: "Creative Learning" },
    { src: "https://images.unsplash.com/photo-1503919919749-a5670f88dc50?q=80&w=2670&auto=format&fit=crop", cat: "Classes", title: "Reading Time" },
    { src: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=2670&auto=format&fit=crop", cat: "Playtime", title: "Joyful Activities" },
    { src: "https://images.unsplash.com/photo-1526649661456-89c7ed4d0018?q=80&w=2670&auto=format&fit=crop", cat: "Events", title: "Future Leaders" },
    { src: "https://images.unsplash.com/photo-1531844251246-9a1bfaae09fc?q=80&w=2356&auto=format&fit=crop", cat: "Sports", title: "Active Kids" },
    { src: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=2670&auto=format&fit=crop", cat: "Events", title: "Celebration" },
  ];

  const filteredImages = filter === "All" ? images : images.filter(img => img.cat === filter);

  return (
    <section id="gallery" className="section-padding bg-white">
      <div className="max-w-7xl mx-auto">
        <SectionHeader 
          title="School Gallery" 
          subtitle="Capturing Moments of JOY" 
        />

        {/* Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setFilter(c)}
              className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${
                filter === c 
                  ? "bg-primary text-white shadow-lg shadow-primary/20" 
                  : "bg-gray-100 text-gray-500 hover:bg-gray-200"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        {/* Masonry Grid */}
        <div className="columns-1 sm:columns-2 lg:columns-3 gap-6 space-y-6">
          <AnimatePresence mode="popLayout">
            {filteredImages.map((img, i) => (
              <motion.div
                key={img.src}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4 }}
                className="relative group cursor-pointer overflow-hidden rounded-[32px] break-inside-avoid shadow-lg"
                onClick={() => setSelectedImage(img.src)}
              >
                <img 
                  src={img.src} 
                  alt={img.title} 
                  className="w-full h-auto object-cover group-hover:scale-110 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-primary/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-6 text-white">
                  <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center mb-4">
                    <Search size={24} />
                  </div>
                  <h4 className="font-display font-black text-xl mb-1">{img.title}</h4>
                  <span className="text-xs font-bold uppercase tracking-widest text-white/80">{img.cat}</span>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Lightbox */}
        <AnimatePresence>
          {selectedImage && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedImage(null)}
              className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-4 md:p-12"
            >
              <button 
                className="absolute top-8 right-8 text-white p-2 hover:bg-white/10 rounded-full"
                onClick={() => setSelectedImage(null)}
              >
                <X size={32} />
              </button>
              <motion.img 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                src={selectedImage} 
                className="max-w-full max-h-full rounded-2xl object-contain shadow-2xl"
                referrerPolicy="no-referrer"
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
};
