import { motion } from "motion/react";
import { ArrowRight, Play, Star, Users, GraduationCap, Award } from "lucide-react";
import { Button } from "../ui/Button";

export const Hero = () => {
  return (
    <section className="relative min-height-screen flex items-center pt-32 pb-20 overflow-hidden">
      {/* Background with dynamic shapes */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 right-0 w-[60%] h-[70%] bg-primary/10 rounded-bl-[200px] -z-10" />
        <div className="absolute bottom-0 left-0 w-[40%] h-[40%] bg-success/10 rounded-tr-[150px] -z-10" />
        
        {/* Animated Background Image Wrapper */}
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] pointer-events-none" />
      </div>

      <div className="max-w-7xl mx-auto px-6 md:px-12 grid lg:grid-cols-2 gap-16 items-center relative z-10">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <div className="inline-flex items-center gap-2 bg-white/50 backdrop-blur-sm px-4 py-2 rounded-full border border-primary/20 mb-8">
            <Star className="text-secondary fill-secondary" size={16} />
            <span className="text-xs font-bold text-gray-700 tracking-wider uppercase">Voted #1 Nursery School in Arusha</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-display font-extrabold leading-[1.05] text-gray-900 mb-8">
            Building <span className="text-primary italic">Bright</span> Futures Through <span className="text-success">Play</span> & Education
          </h1>
          
          <p className="text-lg md:text-xl text-gray-600 mb-10 leading-relaxed max-w-xl">
            Arusha Alliance Nursery School provides a nurturing environment where your child develops creativity, confidence, and excellence from the very start.
          </p>
          
          <div className="flex flex-wrap gap-4">
            <Button variant="primary" size="lg" className="gap-2">
              Apply For Admission <ArrowRight size={20} />
            </Button>
            <Button variant="outline" size="lg" className="gap-2 bg-white/50">
              <Play size={20} className="fill-primary" /> Virtual Tour
            </Button>
          </div>

          <div className="mt-12 grid grid-cols-3 gap-8">
            {[
              { icon: Users, label: "500+", sub: "Happy Students" },
              { icon: GraduationCap, label: "20+", sub: "Expert Teachers" },
              { icon: Award, label: "15+", sub: "Years Excellence" },
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + i * 0.1 }}
                className="flex flex-col gap-1"
              >
                <div className="text-primary mb-1">
                  <stat.icon size={24} />
                </div>
                <div className="text-2xl font-black text-gray-900">{stat.label}</div>
                <div className="text-xs font-bold text-gray-500 uppercase tracking-wider">{stat.sub}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="relative"
        >
          {/* Main Hero Image */}
          <div className="relative z-10 rounded-[40px] overflow-hidden border-8 border-white shadow-2xl shadow-primary/20 rotate-1">
            <img 
              src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=2670&auto=format&fit=crop" 
              alt="Happy children in Arusha Nursery School" 
              className="w-full h-auto aspect-[4/5] object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Decorative Elements */}
          <motion.div
            animate={{ y: [0, -20, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -top-10 -right-10 bg-secondary p-6 rounded-3xl shadow-xl z-20 hidden md:block"
          >
            <div className="text-white font-display font-black text-3xl leading-tight">
              Enroll <br /> Today!
            </div>
          </motion.div>

          <motion.div
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -bottom-6 -left-6 bg-success p-4 rounded-2xl shadow-xl z-0"
          >
            <div className="text-white font-bold text-sm">Join the Alliance Family</div>
          </motion.div>

          {/* Floating Illustration-like accents */}
          <div className="absolute top-1/2 -left-20 w-32 h-32 bg-accent/20 rounded-full blur-3xl -z-10" />
          <div className="absolute bottom-1/4 -right-10 w-48 h-48 bg-primary/20 rounded-full blur-3xl -z-10" />
        </motion.div>
      </div>
    </section>
  );
};
