import { motion } from "motion/react";
import { GraduationCap, BookOpen, Music, Users, ArrowRight } from "lucide-react";
import { SectionHeader } from "../ui/SectionHeader";
import { Button } from "../ui/Button";

export const Academics = () => {
  const programs = [
    {
      title: "Baby Class",
      age: "2.5 - 3 Years",
      icon: Users,
      color: "bg-blue-500",
      skills: ["Social Skills", "Sensory Play", "Motor Skills"],
      desc: "A gentle introduction to school life focusing on emotional security and basic socialization."
    },
    {
      title: "Middle Class",
      age: "3 - 4 Years",
      icon: Music,
      color: "bg-yellow-500",
      skills: ["Language", "Basic Math", "Creative Arts"],
      desc: "Exploring creativity and communication through music, storytelling, and interactive learning."
    },
    {
      title: "Pre-Unit",
      age: "4 - 5 Years",
      icon: BookOpen,
      color: "bg-green-500",
      skills: ["Reading", "Reasoning", "Pre-Writing"],
      desc: "Preparing our scholars for the primary level with advanced literacy and numeracy concepts."
    },
    {
      title: "Nursery Programs",
      age: "5 - 6 Years",
      icon: GraduationCap,
      color: "bg-orange-500",
      skills: ["Problem Solving", "Leadership", "Technology"],
      desc: "Final transition phase emphasizing independence, leadership, and critical academic skills."
    }
  ];

  return (
    <section id="academics" className="section-padding bg-white relative overflow-hidden">
      {/* Background accents */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-[0.03]">
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] bg-primary rounded-full blur-[100px]" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <SectionHeader 
          title="Our Programs" 
          subtitle="Curriculum Tailored for Growth" 
        />

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {programs.map((p, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group relative h-full"
            >
              <div className="bg-white rounded-[32px] p-8 pb-10 shadow-premium border border-gray-100 h-full flex flex-col transition-all duration-500 group-hover:-translate-y-2 group-hover:shadow-2xl">
                {/* Accent Bar */}
                <div className={`absolute top-0 left-1/2 -translate-x-1/2 w-48 h-1 ${p.color} rounded-b-full opacity-0 group-hover:opacity-100 transition-opacity`} />
                
                <div className={`w-16 h-16 ${p.color} text-white rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-${p.color}/20 rotate-3 group-hover:rotate-12 transition-transform`}>
                  <p.icon size={32} />
                </div>
                
                <div className="mb-4">
                  <h3 className="font-display font-black text-2xl text-gray-900 group-hover:text-primary transition-colors">{p.title}</h3>
                  <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">{p.age}</span>
                </div>
                
                <p className="text-sm text-gray-600 mb-6 flex-grow leading-relaxed">
                  {p.desc}
                </p>
                
                <div className="flex flex-wrap gap-2 mb-8">
                  {p.skills.map((s, idx) => (
                    <span key={idx} className="px-3 py-1 bg-gray-50 text-[10px] font-bold text-gray-500 rounded-full border border-gray-100">
                      {s}
                    </span>
                  ))}
                </div>
                
                <button className="flex items-center gap-2 text-sm font-black text-primary group-hover:gap-4 transition-all uppercase tracking-tighter">
                  View Details <ArrowRight size={16} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-20 text-center">
          <Button variant="outline" className="px-10">
            Download Full Curriculum PDF
          </Button>
        </div>
      </div>
    </section>
  );
};
