import { motion } from "motion/react";
import { Calendar, User, ArrowRight } from "lucide-react";
import { SectionHeader } from "../ui/SectionHeader";

export const NewsEvents = () => {
  const news = [
    {
      title: "Arusha Alliance Graduation 2026",
      date: "May 15, 2026",
      author: "Admin",
      img: "https://images.unsplash.com/photo-1524069290683-0457abfe42c3?q=80&w=2670&auto=format&fit=crop",
      desc: "Join us as we celebrate our graduating pre-unit class transition to primary school."
    },
    {
      title: "New Digital Lab Opening",
      date: "June 2, 2026",
      author: "School Board",
      img: "https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=2732&auto=format&fit=crop",
      desc: "We are excited to announce our new interactive smart lab for modern early learning."
    },
    {
      title: "Cultural Diversity Week",
      date: "June 10, 2026",
      author: "Teachers",
      img: "https://images.unsplash.com/photo-1530026405186-ed1f139313f8?q=80&w=2574&auto=format&fit=crop",
      desc: "Celebrating our diverse backgrounds with traditional music, dance, and cultural exchange."
    }
  ];

  return (
    <section id="events" className="section-padding bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <SectionHeader 
          title="News & Events" 
          subtitle="Stay Updated with Alliance" 
        />

        <div className="grid lg:grid-cols-3 gap-12">
          {news.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group cursor-pointer"
            >
              <div className="relative overflow-hidden rounded-[40px] mb-8 shadow-premium aspect-[4/3]">
                <img 
                  src={item.img} 
                  alt={item.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-6 left-6 bg-white/90 backdrop-blur-md px-4 py-2 rounded-2xl flex flex-col items-center shadow-lg">
                  <span className="text-xl font-display font-black text-primary leading-none">{item.date.split(' ')[1].replace(',', '')}</span>
                  <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">{item.date.split(' ')[0]}</span>
                </div>
              </div>
              
              <div className="px-2">
                <div className="flex gap-4 mb-4">
                  <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                    <User size={12} className="text-primary" /> {item.author}
                  </div>
                  <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                    <Calendar size={12} className="text-primary" /> {item.date}
                  </div>
                </div>
                
                <h3 className="font-display font-black text-2xl text-gray-900 mb-4 group-hover:text-primary transition-colors leading-tight">
                  {item.title}
                </h3>
                
                <p className="text-gray-500 text-sm leading-relaxed mb-6">
                  {item.desc}
                </p>
                
                <button className="flex items-center gap-2 text-xs font-black text-primary uppercase tracking-widest group-hover:gap-4 transition-all">
                  Read More <ArrowRight size={14} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
