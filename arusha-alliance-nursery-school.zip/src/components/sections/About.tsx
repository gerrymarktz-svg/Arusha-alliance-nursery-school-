import { motion } from "motion/react";
import { Heart, Target, Lightbulb, ShieldCheck, Star } from "lucide-react";
import { SectionHeader } from "../ui/SectionHeader";
import { Card } from "../ui/Card";

export const About = () => {
  const values = [
    { icon: Star, title: "Excellence", desc: "We strive for high standards in everything we do, nurturing a culture of achievement." },
    { icon: Heart, title: "Care", desc: "Every child is unique and deserves a loving, safe, and supportive environment." },
    { icon: Lightbulb, title: "Creativity", desc: "We encourage imagination and critical thinking through interactive play and arts." },
    { icon: ShieldCheck, title: "Discipline", desc: "Instilling core values and respect that build character for a successful life." },
  ];

  return (
    <section id="about" className="section-padding bg-gray-50/50 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-24">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative z-10 rounded-[40px] overflow-hidden shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=2732&auto=format&fit=crop" 
                alt="School Environment" 
                className="w-full h-auto aspect-video object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            {/* Design accents */}
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-primary/20 rounded-full blur-2xl -z-10" />
            <div className="absolute -top-6 -left-6 w-24 h-24 bg-success/20 rounded-full blur-2xl -z-10" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <SectionHeader 
              title="About Our School" 
              subtitle="Nurturing the Leaders of Tomorrow" 
              align="left"
            />
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Arusha Alliance Nursery School, located in Morombo, Arusha, Tanzania, is an international-standard early learning center dedicated to providing a foundation for life-long learning. 
            </p>
            <p className="text-lg text-gray-600 mb-10 leading-relaxed">
              Our mission is to foster a safe, inclusive, and stimulating environment where children can discover their potential through guided play, exploration, and modern educational methodologies.
            </p>
            
            <div className="flex flex-col gap-6">
              <div className="flex gap-4 items-start p-6 bg-white rounded-3xl shadow-premium border border-gray-100">
                <div className="p-3 bg-primary/10 text-primary rounded-2xl">
                  <Target size={24} />
                </div>
                <div>
                  <h4 className="font-display font-bold text-xl mb-1">Our Vision</h4>
                  <p className="text-sm text-gray-600">To be the preferred nursery school in East Africa, known for excellence in emotional, physical, and cognitive development.</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {values.map((v, i) => (
            <div key={i}>
              <Card delay={i * 0.1} className="text-center group overflow-hidden relative">
                <div className="absolute top-0 right-0 w-16 h-16 bg-primary/5 rounded-bl-[40px] group-hover:scale-150 transition-transform duration-500" />
                <div className="w-16 h-16 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-primary group-hover:text-white transition-colors duration-300">
                  <v.icon size={32} />
                </div>
                <h3 className="font-display font-extrabold text-2xl mb-3 text-gray-900">{v.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{v.desc}</p>
              </Card>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
