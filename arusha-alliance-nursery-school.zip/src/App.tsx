/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Navbar } from "./components/sections/Navbar";
import { Hero } from "./components/sections/Hero";
import { About } from "./components/sections/About";
import { Academics } from "./components/sections/Academics";
import { Features } from "./components/sections/Features";
import { Gallery } from "./components/sections/Gallery";
import { Testimonials } from "./components/sections/Testimonials";
import { Admissions } from "./components/sections/Admissions";
import { NewsEvents } from "./components/sections/NewsEvents";
import { Footer } from "./components/sections/Footer";
import { WhatsAppButton } from "./components/ui/WhatsAppButton";
import { ScrollToTop } from "./components/ui/ScrollToTop";

export default function App() {
  return (
    <div className="min-h-screen bg-white font-sans text-gray-900 selection:bg-primary/20 selection:text-primary overflow-x-hidden">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Academics />
        <Features />
        <Gallery />
        <NewsEvents />
        <Testimonials />
        <Admissions />
      </main>
      <Footer />
      <WhatsAppButton />
      <ScrollToTop />
    </div>
  );
}
